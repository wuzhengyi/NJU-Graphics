﻿using System;

namespace Painting
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.button_white = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_red = new System.Windows.Forms.Button();
            this.button_orange = new System.Windows.Forms.Button();
            this.button_yellow = new System.Windows.Forms.Button();
            this.button_lime = new System.Windows.Forms.Button();
            this.button_aqua = new System.Windows.Forms.Button();
            this.button_blue = new System.Windows.Forms.Button();
            this.button_fuchsia = new System.Windows.Forms.Button();
            this.button_silver = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.openfile = new System.Windows.Forms.Button();
            this.savefile = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.button_front = new System.Windows.Forms.Button();
            this.button_back = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.button_color = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.Ellipse = new System.Windows.Forms.Button();
            this.button_roundness = new System.Windows.Forms.Button();
            this.button_line = new System.Windows.Forms.Button();
            this.rectangle = new System.Windows.Forms.Button();
            this.polygon = new System.Windows.Forms.Button();
            this.bezier = new System.Windows.Forms.Button();
            this.Bsplines = new System.Windows.Forms.Button();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.clip = new System.Windows.Forms.Button();
            this.choose = new System.Windows.Forms.Button();
            this.fill = new System.Windows.Forms.Button();
            this.spin = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button3D = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1125, 731);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 360F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.15585F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.12802F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.62656F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label4, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel1, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.button3D, 2, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 2);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1119, 164);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(123, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(354, 54);
            this.label1.TabIndex = 19;
            this.label1.Text = "形状";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(483, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 54);
            this.label4.TabIndex = 7;
            this.label4.Text = "3D";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Controls.Add(this.button_white);
            this.flowLayoutPanel1.Controls.Add(this.button3);
            this.flowLayoutPanel1.Controls.Add(this.button_red);
            this.flowLayoutPanel1.Controls.Add(this.button_orange);
            this.flowLayoutPanel1.Controls.Add(this.button_yellow);
            this.flowLayoutPanel1.Controls.Add(this.button_lime);
            this.flowLayoutPanel1.Controls.Add(this.button_aqua);
            this.flowLayoutPanel1.Controls.Add(this.button_blue);
            this.flowLayoutPanel1.Controls.Add(this.button_fuchsia);
            this.flowLayoutPanel1.Controls.Add(this.button_silver);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(583, 2);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(232, 106);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // button_white
            // 
            this.button_white.BackColor = System.Drawing.Color.White;
            this.button_white.Location = new System.Drawing.Point(3, 2);
            this.button_white.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_white.Name = "button_white";
            this.button_white.Size = new System.Drawing.Size(51, 25);
            this.button_white.TabIndex = 0;
            this.button_white.Tag = "9999";
            this.button_white.UseVisualStyleBackColor = false;
            this.button_white.Click += new System.EventHandler(this.button_white_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(60, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(51, 25);
            this.button3.TabIndex = 1;
            this.button3.Tag = "9999";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button_black_Click);
            // 
            // button_red
            // 
            this.button_red.BackColor = System.Drawing.Color.Red;
            this.button_red.Location = new System.Drawing.Point(117, 2);
            this.button_red.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_red.Name = "button_red";
            this.button_red.Size = new System.Drawing.Size(51, 25);
            this.button_red.TabIndex = 2;
            this.button_red.Tag = "9999";
            this.button_red.UseVisualStyleBackColor = false;
            this.button_red.Click += new System.EventHandler(this.button_red_Click);
            // 
            // button_orange
            // 
            this.button_orange.BackColor = System.Drawing.Color.Orange;
            this.button_orange.Location = new System.Drawing.Point(174, 2);
            this.button_orange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_orange.Name = "button_orange";
            this.button_orange.Size = new System.Drawing.Size(51, 25);
            this.button_orange.TabIndex = 3;
            this.button_orange.Tag = "9999";
            this.button_orange.UseVisualStyleBackColor = false;
            this.button_orange.Click += new System.EventHandler(this.button_orange_Click);
            // 
            // button_yellow
            // 
            this.button_yellow.BackColor = System.Drawing.Color.Yellow;
            this.button_yellow.Location = new System.Drawing.Point(3, 31);
            this.button_yellow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_yellow.Name = "button_yellow";
            this.button_yellow.Size = new System.Drawing.Size(51, 25);
            this.button_yellow.TabIndex = 4;
            this.button_yellow.Tag = "9999";
            this.button_yellow.UseVisualStyleBackColor = false;
            this.button_yellow.Click += new System.EventHandler(this.button_yellow_Click);
            // 
            // button_lime
            // 
            this.button_lime.BackColor = System.Drawing.Color.Lime;
            this.button_lime.Location = new System.Drawing.Point(60, 31);
            this.button_lime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_lime.Name = "button_lime";
            this.button_lime.Size = new System.Drawing.Size(51, 25);
            this.button_lime.TabIndex = 5;
            this.button_lime.Tag = "9999";
            this.button_lime.UseVisualStyleBackColor = false;
            this.button_lime.Click += new System.EventHandler(this.button_lime_Click);
            // 
            // button_aqua
            // 
            this.button_aqua.BackColor = System.Drawing.Color.Aqua;
            this.button_aqua.Location = new System.Drawing.Point(117, 31);
            this.button_aqua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_aqua.Name = "button_aqua";
            this.button_aqua.Size = new System.Drawing.Size(51, 25);
            this.button_aqua.TabIndex = 6;
            this.button_aqua.Tag = "9999";
            this.button_aqua.UseVisualStyleBackColor = false;
            this.button_aqua.Click += new System.EventHandler(this.button_aqua_Click);
            // 
            // button_blue
            // 
            this.button_blue.BackColor = System.Drawing.Color.Blue;
            this.button_blue.Location = new System.Drawing.Point(174, 31);
            this.button_blue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_blue.Name = "button_blue";
            this.button_blue.Size = new System.Drawing.Size(51, 25);
            this.button_blue.TabIndex = 7;
            this.button_blue.Tag = "9999";
            this.button_blue.UseVisualStyleBackColor = false;
            this.button_blue.Click += new System.EventHandler(this.button_blue_Click);
            // 
            // button_fuchsia
            // 
            this.button_fuchsia.BackColor = System.Drawing.Color.Fuchsia;
            this.button_fuchsia.Location = new System.Drawing.Point(3, 60);
            this.button_fuchsia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_fuchsia.Name = "button_fuchsia";
            this.button_fuchsia.Size = new System.Drawing.Size(51, 25);
            this.button_fuchsia.TabIndex = 8;
            this.button_fuchsia.Tag = "9999";
            this.button_fuchsia.UseVisualStyleBackColor = false;
            this.button_fuchsia.Click += new System.EventHandler(this.button_fuchsia_Click);
            // 
            // button_silver
            // 
            this.button_silver.BackColor = System.Drawing.Color.Silver;
            this.button_silver.Location = new System.Drawing.Point(60, 60);
            this.button_silver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_silver.Name = "button_silver";
            this.button_silver.Size = new System.Drawing.Size(51, 25);
            this.button_silver.TabIndex = 9;
            this.button_silver.Tag = "9999";
            this.button_silver.UseVisualStyleBackColor = false;
            this.button_silver.Click += new System.EventHandler(this.button_silver_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.openfile, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.savefile, 0, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 2);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(114, 106);
            this.tableLayoutPanel4.TabIndex = 13;
            // 
            // openfile
            // 
            this.openfile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.openfile.Image = ((System.Drawing.Image)(resources.GetObject("openfile.Image")));
            this.openfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.openfile.Location = new System.Drawing.Point(3, 2);
            this.openfile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.openfile.Name = "openfile";
            this.openfile.Size = new System.Drawing.Size(108, 49);
            this.openfile.TabIndex = 0;
            this.openfile.Text = "打开";
            this.openfile.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.openfile.UseVisualStyleBackColor = true;
            this.openfile.Click += new System.EventHandler(this.openfile_Click);
            // 
            // savefile
            // 
            this.savefile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.savefile.Image = ((System.Drawing.Image)(resources.GetObject("savefile.Image")));
            this.savefile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.savefile.Location = new System.Drawing.Point(3, 55);
            this.savefile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savefile.Name = "savefile";
            this.savefile.Size = new System.Drawing.Size(108, 49);
            this.savefile.TabIndex = 1;
            this.savefile.Text = "保存";
            this.savefile.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.savefile.UseVisualStyleBackColor = true;
            this.savefile.Click += new System.EventHandler(this.savefile_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.button_front, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.button_back, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(821, 2);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(151, 106);
            this.tableLayoutPanel5.TabIndex = 14;
            // 
            // button_front
            // 
            this.button_front.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_front.Image = ((System.Drawing.Image)(resources.GetObject("button_front.Image")));
            this.button_front.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_front.Location = new System.Drawing.Point(78, 2);
            this.button_front.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_front.Name = "button_front";
            this.button_front.Size = new System.Drawing.Size(70, 102);
            this.button_front.TabIndex = 13;
            this.button_front.Text = "恢复";
            this.button_front.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_front.UseVisualStyleBackColor = true;
            this.button_front.Click += new System.EventHandler(this.button_front_Click);
            // 
            // button_back
            // 
            this.button_back.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_back.Image = ((System.Drawing.Image)(resources.GetObject("button_back.Image")));
            this.button_back.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_back.Location = new System.Drawing.Point(3, 2);
            this.button_back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(69, 102);
            this.button_back.TabIndex = 12;
            this.button_back.Text = "撤销";
            this.button_back.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_back.UseVisualStyleBackColor = true;
            this.button_back.Click += new System.EventHandler(this.button_back_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(821, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 54);
            this.label3.TabIndex = 2;
            this.label3.Text = "状态";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.05882F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.94118F));
            this.tableLayoutPanel6.Controls.Add(this.button_color, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(583, 112);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(232, 50);
            this.tableLayoutPanel6.TabIndex = 15;
            // 
            // button_color
            // 
            this.button_color.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_color.BackColor = System.Drawing.Color.Black;
            this.button_color.Location = new System.Drawing.Point(83, 2);
            this.button_color.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_color.Name = "button_color";
            this.button_color.Size = new System.Drawing.Size(54, 46);
            this.button_color.TabIndex = 11;
            this.button_color.Tag = "9999";
            this.button_color.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoEllipsis = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 50);
            this.label2.TabIndex = 7;
            this.label2.Text = "颜色";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(3, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 54);
            this.label5.TabIndex = 12;
            this.label5.Text = "文件";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Controls.Add(this.Ellipse, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.button_roundness, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.button_line, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.rectangle, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.polygon, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.bezier, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.Bsplines, 2, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(123, 2);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(354, 106);
            this.tableLayoutPanel3.TabIndex = 11;
            // 
            // Ellipse
            // 
            this.Ellipse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Ellipse.Image = ((System.Drawing.Image)(resources.GetObject("Ellipse.Image")));
            this.Ellipse.Location = new System.Drawing.Point(91, 2);
            this.Ellipse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Ellipse.Name = "Ellipse";
            this.Ellipse.Size = new System.Drawing.Size(82, 49);
            this.Ellipse.TabIndex = 9;
            this.Ellipse.UseVisualStyleBackColor = true;
            this.Ellipse.Click += new System.EventHandler(this.button_ellipse_Click);
            // 
            // button_roundness
            // 
            this.button_roundness.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_roundness.Image = ((System.Drawing.Image)(resources.GetObject("button_roundness.Image")));
            this.button_roundness.Location = new System.Drawing.Point(3, 2);
            this.button_roundness.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_roundness.Name = "button_roundness";
            this.button_roundness.Size = new System.Drawing.Size(82, 49);
            this.button_roundness.TabIndex = 8;
            this.button_roundness.UseVisualStyleBackColor = true;
            this.button_roundness.Click += new System.EventHandler(this.button_roundness_Click);
            // 
            // button_line
            // 
            this.button_line.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_line.Image = ((System.Drawing.Image)(resources.GetObject("button_line.Image")));
            this.button_line.Location = new System.Drawing.Point(179, 2);
            this.button_line.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_line.Name = "button_line";
            this.button_line.Size = new System.Drawing.Size(82, 49);
            this.button_line.TabIndex = 5;
            this.button_line.UseVisualStyleBackColor = true;
            this.button_line.Click += new System.EventHandler(this.button_line_Click_1);
            // 
            // rectangle
            // 
            this.rectangle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rectangle.Image = ((System.Drawing.Image)(resources.GetObject("rectangle.Image")));
            this.rectangle.Location = new System.Drawing.Point(267, 2);
            this.rectangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rectangle.Name = "rectangle";
            this.rectangle.Size = new System.Drawing.Size(84, 49);
            this.rectangle.TabIndex = 11;
            this.rectangle.UseVisualStyleBackColor = true;
            this.rectangle.Click += new System.EventHandler(this.button_rectangle_Click);
            // 
            // polygon
            // 
            this.polygon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.polygon.Image = ((System.Drawing.Image)(resources.GetObject("polygon.Image")));
            this.polygon.Location = new System.Drawing.Point(3, 55);
            this.polygon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.polygon.Name = "polygon";
            this.polygon.Size = new System.Drawing.Size(82, 49);
            this.polygon.TabIndex = 12;
            this.polygon.UseVisualStyleBackColor = true;
            this.polygon.Click += new System.EventHandler(this.button_polygon_Click);
            // 
            // bezier
            // 
            this.bezier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bezier.Image = ((System.Drawing.Image)(resources.GetObject("bezier.Image")));
            this.bezier.Location = new System.Drawing.Point(91, 55);
            this.bezier.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bezier.Name = "bezier";
            this.bezier.Size = new System.Drawing.Size(82, 49);
            this.bezier.TabIndex = 13;
            this.bezier.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bezier.UseVisualStyleBackColor = true;
            this.bezier.Click += new System.EventHandler(this.bezier_Click);
            // 
            // Bsplines
            // 
            this.Bsplines.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Bsplines.Image = ((System.Drawing.Image)(resources.GetObject("Bsplines.Image")));
            this.Bsplines.Location = new System.Drawing.Point(179, 55);
            this.Bsplines.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Bsplines.Name = "Bsplines";
            this.Bsplines.Size = new System.Drawing.Size(82, 49);
            this.Bsplines.TabIndex = 14;
            this.Bsplines.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Bsplines.UseVisualStyleBackColor = true;
            this.Bsplines.Click += new System.EventHandler(this.Bsplines_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.clip, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.choose, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.fill, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.spin, 1, 1);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(978, 2);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(138, 106);
            this.tableLayoutPanel7.TabIndex = 17;
            // 
            // clip
            // 
            this.clip.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clip.Image = ((System.Drawing.Image)(resources.GetObject("clip.Image")));
            this.clip.Location = new System.Drawing.Point(3, 55);
            this.clip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clip.Name = "clip";
            this.clip.Size = new System.Drawing.Size(63, 49);
            this.clip.TabIndex = 16;
            this.clip.UseVisualStyleBackColor = true;
            this.clip.Click += new System.EventHandler(this.button_clip_Click);
            // 
            // choose
            // 
            this.choose.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.choose.Image = ((System.Drawing.Image)(resources.GetObject("choose.Image")));
            this.choose.Location = new System.Drawing.Point(72, 2);
            this.choose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.choose.Name = "choose";
            this.choose.Size = new System.Drawing.Size(63, 49);
            this.choose.TabIndex = 15;
            this.choose.UseVisualStyleBackColor = true;
            this.choose.Click += new System.EventHandler(this.button_selected_Click);
            // 
            // fill
            // 
            this.fill.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fill.Image = ((System.Drawing.Image)(resources.GetObject("fill.Image")));
            this.fill.Location = new System.Drawing.Point(3, 2);
            this.fill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fill.Name = "fill";
            this.fill.Size = new System.Drawing.Size(63, 49);
            this.fill.TabIndex = 14;
            this.fill.UseVisualStyleBackColor = true;
            this.fill.Click += new System.EventHandler(this.button_fill_Click);
            // 
            // spin
            // 
            this.spin.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spin.Image = ((System.Drawing.Image)(resources.GetObject("spin.Image")));
            this.spin.Location = new System.Drawing.Point(72, 55);
            this.spin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.spin.Name = "spin";
            this.spin.Size = new System.Drawing.Size(63, 49);
            this.spin.TabIndex = 17;
            this.spin.UseVisualStyleBackColor = true;
            this.spin.Click += new System.EventHandler(this.spin_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(978, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 54);
            this.label6.TabIndex = 16;
            this.label6.Text = "功能";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button3D
            // 
            this.button3D.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button3D.Image = ((System.Drawing.Image)(resources.GetObject("button3D.Image")));
            this.button3D.Location = new System.Drawing.Point(483, 3);
            this.button3D.Name = "button3D";
            this.button3D.Size = new System.Drawing.Size(94, 104);
            this.button3D.TabIndex = 18;
            this.button3D.UseVisualStyleBackColor = true;
            this.button3D.Click += new System.EventHandler(this.button3D_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox.BackColor = System.Drawing.Color.Silver;
            this.pictureBox.Location = new System.Drawing.Point(3, 170);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(1119, 559);
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            this.pictureBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1125, 731);
            this.Controls.Add(this.tableLayoutPanel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "画图 （151220129计科吴政亿）";
            this.TransparencyKey = System.Drawing.Color.LightGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        private void ChangePictureBoxSize(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button button_white;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button_red;
        private System.Windows.Forms.Button button_orange;
        private System.Windows.Forms.Button button_yellow;
        private System.Windows.Forms.Button button_lime;
        private System.Windows.Forms.Button button_aqua;
        private System.Windows.Forms.Button button_blue;
        private System.Windows.Forms.Button button_fuchsia;
        private System.Windows.Forms.Button button_silver;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button openfile;
        private System.Windows.Forms.Button savefile;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button button_front;
        private System.Windows.Forms.Button button_back;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Button button_color;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button Ellipse;
        private System.Windows.Forms.Button button_roundness;
        private System.Windows.Forms.Button button_line;
        private System.Windows.Forms.Button rectangle;
        private System.Windows.Forms.Button polygon;
        private System.Windows.Forms.Button bezier;
        private System.Windows.Forms.Button Bsplines;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button clip;
        private System.Windows.Forms.Button choose;
        private System.Windows.Forms.Button fill;
        private System.Windows.Forms.Button spin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3D;
    }

    
}

